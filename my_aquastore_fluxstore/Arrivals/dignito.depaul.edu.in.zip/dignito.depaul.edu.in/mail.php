<?php
// Where will you get the forms' results?
define("CONTACT_FORM", 'dignito@depaul.edu.in');
?>