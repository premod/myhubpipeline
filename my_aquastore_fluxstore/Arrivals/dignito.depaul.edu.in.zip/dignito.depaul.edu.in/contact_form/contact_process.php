<?php

include dirname(dirname(__FILE__)).'/mail.php';

error_reporting (E_ALL ^ E_NOTICE);

$post = (!empty($_POST)) ? true : false;

if($post)
{
include 'email_validation.php';

$name = stripslashes($_POST['name']);
$colname = stripslashes($_POST['colname']);
$mobnumber = stripslashes($_POST['number']);
$email = trim($_POST['email']);
$comp = stripslashes($_POST['competitions']);
$participants = stripslashes($_POST['parti']);
$accomodation = stripslashes($_POST['Accom']);
$message = stripslashes($_POST['message']);


$error = '';

// Check name

if(!$name)
{
$error .= 'Please enter your name.<br />';
}

// Check email

if(!$email)
{
$error .= 'Please enter an e-mail address.<br />';
}

if($email && !ValidateEmail($email))
{
$error .= 'Please enter a valid e-mail address.<br />';
}

// Check message (length)

if(!$message || strlen($message) < 10)
{
$error .= "Please enter your message. It should have at least 10 characters.<br />";
}

// Check Mobile Number (length)

if(!$mobnumber || strlen($mobnumber) < 10)
{
$error .= "Please enter your Correct Mobile Number. Mobile Number have 10 Digits Right?.<br />";
}

// Check participants (length)

if(!$participants || strlen($participants) < 0)
{
$error .= "Please enter atleast 1 Participant.<br />";
}

  function clean_string($string) {
 
      $bad = array("content-type","bcc:","to:","cc:","href");
 
      return str_replace($bad,"",$string);
 
    }

	$email_message .= "Name: ".clean_string($name)."\n";
 
    $email_message .= "From College: ".clean_string($colname)."\n";
 
    $email_message .= "Email ID: ".clean_string($email)."\n";
 
    $email_message .= "Contact Number: ".clean_string($mobnumber)."\n";
	
	$email_message .= "Competition: ".clean_string($comp)."\n";
 
    $email_message .= "Participants Number: ".clean_string($participants)."\n";
	
	$email_message .= "Accomodation Needed: ".clean_string($accomodation)."\n";
	
	$email_message .= "Message: ".clean_string($message)."\n";


if(!$error)
{
$mail = mail(CONTACT_FORM, $comp, $email_message,
     "From: ".$name." <".$email.">\r\n"
    ."Reply-To: ".$email."\r\n"
    ."X-Mailer: PHP/" . phpversion());


if($mail)
{
echo 'OK';
}

}
else
{
echo '<div class="notification_error">'.$error.'</div>';
}

}
?>